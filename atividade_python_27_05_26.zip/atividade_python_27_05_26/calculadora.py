print(
    '='*20
)
print(
    f'{'CALCULADORA':^20}'
)
print(
    '='*20
)

n1 = float(
    input('Digite um número: ')
)
n2 = float(
    input('Digite outro número: ')
)

print(
    'Qual operação deseja realizar?\n'
    '[1] ADIÇÃO\n'
    '[2] SUBTRAÇÃO\n'
    '[3] MULTIPLICAÇÃO\n'
    '[4] DIVISÃO\n'
)

op = int(
    input('Digite a sua opção: ')
)

if op == 1:
    soma = n1 + n2
    print(
        f'Você escolheu a opção {op}. O programa vai realizar uma ADIÇÃO.\n'
        f'RESULTADO: {n1} + {n2} = {soma}'
    )
elif op == 2:
    soma = n1 - n2
    print(
        f'Você escolheu a opção {op}. O programa vai realizar uma SUBTRAÇÃO.\n'
        f'RESULTADO: {n1} - {n2} = {soma}'
    )
elif op == 3:
    soma = n1 * n2
    print(
        f'Você escolheu a opção {op}. O programa vai realizar uma MULTIPLICA'
        'ÇÃO.\n'
        f'RESULTADO: {n1} x {n2} = {soma}'
    )
elif op == 4:
    soma = n1 / n2
    print(
        f'Você escolheu a opção {op}. O programa vai realizar uma DIVISÃO.\n'
        f'RESULTADO: {n1} / {n2} = {soma}'
    )
    