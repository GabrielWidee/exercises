print(
    '='*20
)
print(
    f'{'LOJA PAGUE MAIS\n':^20}'
    f'{'E LEVE MENOS\n':^15}'
)
print(
    '='*20
)

preco = float(
    input('Digite o preço do produto: R$')
)
if preco > 500:
    desconto = preco - (preco * 20 / 100)
    print(
        'O seu produto foi acima de R$500 reais.\n'
        f'Você obeve um desconto de 20%. Com o preço final de R${desconto}')
elif preco > 100:
    desconto = preco - (preco * 10 / 100)
    print(
        'O seu produto foi acima de R$100 reais.\n'
        f'Você obeve um desconto de 10%. Com o preço final de R${desconto}')
else:
    print(
        f'O valor do seu produto de R${preco} não tem desconto no sistema.'
        )