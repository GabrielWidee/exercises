from math import factorial

print('========== CALCULO FATORIAL ==========')
n = int(input('Digite um número: '))
fat = factorial(n)
print(f'Calculando {n}! =', end=' ')
while n > 0:
    print(f'{n} x'.replace('1 x', '1'), end=' ')
    n -= 1
print(f'= {fat}')
