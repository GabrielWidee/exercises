idade = int(
    input('Digite sua idade: ')
)

if idade <= 12:
    print(
        'Você ainda é uma Criança.'
        )
elif 13 <= idade <= 17:
    print(
        'Você já é um Adolescente.'
    )
elif 18 <= idade <= 59:
    print(
        'Você já é um Adulto.'
    )
else:
    print(
        'Você já é um Idoso.'
    )