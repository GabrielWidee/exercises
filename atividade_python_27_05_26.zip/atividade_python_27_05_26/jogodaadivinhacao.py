secreto = 10

while True:
    jogador = int(
        input('Tente adivinhar o valor secreto: ')
    )

    if secreto > jogador:
        print(
            'Valor digitado menor que o secreto.'
        )
    elif secreto < jogador:
        print(
            'Valor digitado maior que o secreto'
        )
    if jogador != secreto:
        print(
            'Tente novamente.'
        )
        print(
            '=' * 20
        )
    if jogador == secreto:
        break
print(
    'Você acertou. Fim de jogo!'
)
