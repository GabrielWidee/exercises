n1 = int(
    input('Digite o 1º valor: ')
)
n2 = int(
    input('Digite o 2º valor: ')
)
n3 = int(
    input('Digite o 3º valor: ')
)

if n1 > n2 and n1 > n3:
    print(
        f'{n1} foi o maior valor digitado.'
    )
elif n2 > n1 and n2 > n3:
    print(
        f'{n2} foi o maior valor digitado.'
    )
elif n3 > n1 and n3 > n2:
    print(
        f'{n3} foi o maior valor digitado.'
    )
else:
    print(
        'Todos são iguais.'
    )