n1 = int(
    input('Digite o 1º valor: ')
)
n2 = int(
    input('Digite o 2º valor: ')
)

if n1 > n2:
    print(
        f'{n1} é maior que {n2}.'
    )
elif n2 > n1:
    print(
        f'{n2} é maior que {n1}'
    )
else:
    print(
        'Ambos são iguais.'
    )