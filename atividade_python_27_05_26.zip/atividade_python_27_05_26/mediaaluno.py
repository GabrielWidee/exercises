soma = 0

for c in range(2):

    nota = float(
        input(f'Digite a {c+1}º nota: ')
    )

    soma += nota

media = soma / 2

print(
    f'Você teve uma média de {media}\n'
    f'Classificação: ', end=''
)

if media >= 7:
    print(
        'APROVADO!'
    )
elif 5 <= media < 6.9:
    print(
        'RECUPERAÇÃO!'
    )
elif media < 5:
    print(
        'REPROVADO!'
    )
    