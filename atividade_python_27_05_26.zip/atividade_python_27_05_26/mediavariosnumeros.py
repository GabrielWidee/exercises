c = media = soma = 0

while True:
    n = int(
        input('Digite um valor [digite 0 para parar]: ')
    )
    if n == 0:
        break
    soma += n
    c += 1
media = soma / c
print(
    '='*25
)
print(
    f'A quantidade de números digitados foi: {c}\n'
    f'A soma entre eles foi: {soma}\n'
    f'A média da soma foi: {media}'
)