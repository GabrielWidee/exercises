from time import sleep
print('NÚMEROS PARES')
for cont in range(2, 102, 2):
    print(f'{cont} |'.replace('100 |', '100'), end=' ', flush= True)
    sleep(1)