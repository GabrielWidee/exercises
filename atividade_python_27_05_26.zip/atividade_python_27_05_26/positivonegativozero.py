n = int(
    input('Digite um valor: ')
)

if n > 0:
    print(
        'Valor POSITIVO.'
    )
elif n < 0:
    print(
        'Valor NEGATIVO.'
    )
else:
    print(
        'Valor NEUTRO.'
    )