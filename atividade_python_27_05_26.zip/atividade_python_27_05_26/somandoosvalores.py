soma = 0
for c in range(1, 6):
    n = int(
        input(f'Digite o {c}º valor: ')
    )
    soma += n
print(
    f'A soma total dos valores é: {soma}'
)