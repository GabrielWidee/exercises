print(
    '='*20
)
print(
    f'{'TABUADA':^20}'
)
print(
    '='*20
)
n = int(
    input('Digite um número: ')
)
for c in range(1, 11):
    print(
        f'{n} x {c:>2} = {n * c:>2}'
    )