senha0 = 1234

while True:
    senha1 = int(
        input('Digite sua senha: ')
    )
    if senha1 != senha0:
        print(
            'Senha incorreta. Tente novamente.'
        )

    if senha1 == senha0:
        break
print(
    'Login Realizado!'
)